using Microsoft.EntityFrameworkCore.Metadata.Internal;
using OnlineMarketApp.Models;

namespace OnlineMarketApp.Dtos.Products;

public class ShowProductByCountShopDto
{
    public int ProductId { get; set; }
    public int Count { get; set; }
}