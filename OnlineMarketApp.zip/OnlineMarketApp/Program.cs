﻿using System.Diagnostics.Tracing;
using Microsoft.EntityFrameworkCore;
using OnlineMarketApp;
using OnlineMarketApp.Customers;
using OnlineMarketApp.Dtos.Orders;
using OnlineMarketApp.Employees;
using OnlineMarketApp.Models;
using OnlineMarketApp.OrderItems;
using OnlineMarketApp.Orders;
using OnlineMarketApp.Products;
using OnlineMarketApp.Stores;
using OnlineMarketApp.Users;
using static System.Console;

WriteLine("hello comrade!!");

var dataContext = new EFDataContext();
var storeRepository = new EFStoreRepository(dataContext);
var productRepository = new EFProductRepository(dataContext);
var orderRepository = new EFOrderRepository(dataContext);
var userRepository = new EFUserRepository(dataContext);
var employeeRepository = new EFEmployeeRepository(dataContext);
var customerRepository = new EFCustomerRepository(dataContext);
var orderItemRepository = new EFOrderitemRepository(dataContext);

var workAgain = true;
while (workAgain)
{
    ShowMenu();
    var choice = GetUserIntNumber("choice");

    switch (choice)
    {
        case 1:
            var store = AddStore(GetUserStrInput("Stores name"));
            dataContext.SaveChanges();
            break;
        
        case 2: AddProduct(GetUserStrInput("product name")
            ,GetDecimalNumber("Price")
            , GetUserIntNumber("storeId"),
            GetUserStrInput("Description"));break;
        
        case 3:
            dataContext.Database.BeginTransaction();
            try
            {
                var user = AddUser(GetUserStrInput("First name"),
                    GetUserStrInput("Last name"),
                    GetUserStrInput("phone number"),
                    GetUserStrInput("Email"));

                dataContext.SaveChanges();

                var customer = AddCustomer(GetUserStrInput("Postal code"),
                    GetUserStrInput("Address"),
                    user.Id);

                dataContext.SaveChanges();
                dataContext.Database.CommitTransaction();
            }
            catch
            {
                dataContext.Database.RollbackTransaction();
            }

            break;
        
        case 4:
            dataContext.Database.BeginTransaction();
            try
            {
                var user = AddUser(GetUserStrInput("First name"),
                    GetUserStrInput("Last name"),
                    GetUserStrInput("phone number"),
                    GetUserStrInput("Email"));
                dataContext.SaveChanges();
                
                var employee =AddEmployee(GetUserStrInput("personnel number"),
                    user.Id,
                    GetUserIntNumber("Stores id"));

                dataContext.SaveChanges();
                
                dataContext.Database.CommitTransaction();
            }
            catch 
            {
                dataContext.Database.RollbackTransaction();
            }
            break;
        
        case 5:
           var order = AddOrder(GetUserIntNumber("costumerID"), GetDateTime());
            dataContext.SaveChanges();
            AddShopOrder(order);
            dataContext.SaveChanges();
            break;
        
        case 6 : ShowStores(); break;
        case 7 : ShowProducts(); break;
        case 8 : ShowProductByCountShop(); break;
        case 9 : ShowCustomers(); break;
        case 10: ShowUsers(); break;
        case 11 : ShowOrders(); break;
        case 12 : ShowEmployees(); break;
        
        case 13 : DeleteStore();
            dataContext.SaveChanges();
            break;
        
        case 14 :DeleteProduct();
            dataContext.SaveChanges();
            break;
        
        case 15 : 
            var customerToDelete = DeleteCustomer();
            dataContext.SaveChanges();
            DeleteUser(customerToDelete.UserId);
            dataContext.SaveChanges();
            
            break;
        case 16 : var employeeToDelete = DeleteEmployee();
            dataContext.SaveChanges();
            DeleteUser(employeeToDelete.UserId);
            dataContext.SaveChanges(); break;
        
        case 17 : workAgain = false; break;
    }
}

static void ShowMenu()
{
   
    WriteLine($"[1] Add Store\n" +
              $"[2] Add Product\n" +
              $"[3] Add Customer\n" +
              $"[4] Add Employee\n" +
              $"[5] Add Order\n" +
              $"[6] Show Stores\n" +
              $"[7] Show Products\n" +
              $"[8] Show Products by count Ordering\n" +
              $"[9] Show Customers\n" +
              $"[10] Show users\n" +
              $"[11] Show Orders\n" +
              $"[12] Show Employee\n" +
              $"[13] Delete Stores\n" +
              $"[14] Delete Product\n" +
              $"[15] Delete Customer\n" +
              $"[16] Delete Employee\n" +
              $"[17] Exit");
}

static int GetUserIntNumber(string msg)
{
    var canParseNumber = false;
    var number = 0;
    while (!canParseNumber)
    {
        WriteLine($"Enter your {msg} :");
        canParseNumber = int.TryParse(ReadLine(), out number);
    }

    return number;
}

static string GetUserStrInput(string msg)
{
    Write($"Enter {msg} :");
    var input = ReadLine();

    if (input != null) return input;
    WriteLine($"{msg} is invalid !! . try again !");
    return GetUserStrInput(msg);
}

static decimal GetDecimalNumber(string msg)
{
    var canParseNumber = false;
    decimal number = 0;
    while (!canParseNumber)
    {
        WriteLine($"Enter your {msg} :");
        canParseNumber = decimal.TryParse(ReadLine(), out number);
    }

    return number;
}

static DateTime GetDateTime()
{
    var canParseDate = false;
    DateTime time = default;
    while (!canParseDate)
    {
        WriteLine(" Enter Time for this Order :");
        canParseDate = DateTime.TryParse(ReadLine(), out time);
    }

    return time;
}


 User AddUser(string firstName,
    string lastName,
    string phoneNumber,
    string? email)
 {
     var user = new User
     {
         FirstName = firstName,
         LastName = lastName,
         PhoneNumber = phoneNumber,
         Email = string.IsNullOrEmpty(email)?"null":email
     };

     userRepository.AddUser(user);
     
     return user;
 }

 Customer AddCustomer(string postalCode, string address, int userId)
 {
     var customer = new Customer()
     {
         PostalCode = postalCode,
         Address = address,
         UserId = userId
     };
     
     customerRepository.AddCustomer(customer);

     return customer;
 }

 Store AddStore(string name)
 {
     var store = new Store
     {
         Name = name
     };

     storeRepository.AddStore(store);

     return store;
 }

 Product AddProduct(string name,
     decimal price,
     int storeId,
     string? description)
 {
     var store = storeRepository.GetStoreById(storeId);

     var product = new Product
     {
         Name = name,
         Price = price,
         StoreId = store.Id,
         Description = string.IsNullOrEmpty(description) ? "description" : description
     };
     
     productRepository.AddProduct(product);
     return product;
 }

 Employee AddEmployee(string personnelNum, int userId, int? storeId)
 {
     var employee = new Employee()
     {
         PersonalId = personnelNum,
         UserId = userId,
         StoreId = storeId,
     };
     
     employeeRepository.AddEmployee(employee);

     return employee;
 }

 Order AddOrder(int customerId, DateTime date)
 {
     var order = new Order()
     {
        CustomerId = customerId,
        OrderDate = date,
        OrderItems = [],
        TotalPrice = 0,
     };
     
     orderRepository.AddShopping(order);

     return order;

 }

 Order AddShopOrder(Order order)
 {
     var orderId = order.Id;
     order.OrderItems = GetOrderItems(orderId); 
     order.TotalPrice = order.OrderItems.Sum(item => item.Quantity * item.Price);
     
     orderItemRepository.AddOrderItem(order);
     
     dataContext.SaveChanges(); 
     
     orderRepository.UpdateOrder(order);
     
     return order;

 }

 List<OrderItem> GetOrderItems(int orderId)
 {
     List<OrderItem> items = new List<OrderItem>(); 
     var numItems = GetUserIntNumber("How many order items do you want to add?");

     for (int i = 0; i < numItems; i++)
     {
         var productId = GetUserIntNumber("Product Id");

         var price = productRepository.GetPriceWithProductId(orderId);
         var quantity = GetUserIntNumber("Quantity");

         var item = new OrderItem()
         {
             Price = price,
             Quantity = quantity,
             OrderId = orderId,
             ProductId = productId
         };

         items.Add(item);
     }

     return items;
 }

 void ShowOrders()
 {
     var orders = orderRepository.GetOrders();
     
     foreach (var orderWithProduct in orders)
     {
         WriteLine($"Order ID: {orderWithProduct.Id}");
         WriteLine($"Order Date: {orderWithProduct.Date}");
         WriteLine($"Customer Name: {orderWithProduct.CustomerName}");
         WriteLine($"Product Name: {orderWithProduct.ProductName}");
         WriteLine($"Quantity: {orderWithProduct.Quantity}");
         WriteLine($"Price: {orderWithProduct.Price}");
         WriteLine("----------------------");
     }
 }

 void ShowProducts()
 {
     var products = productRepository.GetProductsDto();
     
     foreach (var product in products)
     {
         WriteLine($"{product.Id}- {product.Name} with {product.Price} " +
                   $"and description is {product.Description}");
     }
 }

 void ShowCustomers()
 {
     var customers = customerRepository.GetCustomersDto();
     
     foreach (var item in customers)
     {
         WriteLine($"{item.Id}- {item.FirstName} {item.LastName}\t phoneNumber:{item.PhoneNumber} " +
                   $"Address :{item.Address}");
     }
 }

 void ShowEmployees()
 {
     var employees = employeeRepository.GetEmployeeDto();
     
     foreach (var item in employees)
     {
         WriteLine($"{item.Id}- {item.FirstName} {item.LastName}\t phoneNumber:{item.PhoneNumber} " +
                   $"personnel Id :{item.PersonnelId}" +
                   $"-StoreName :{item.StoreName}");
     }
 }

 void ShowStores()
 {
     var stores = storeRepository.GetStoresDto();
     
     foreach (var store in stores)
     {
         Console.WriteLine($"{store.Id} - {store.Name}");
     }
 }

 void ShowProductByCountShop()
 {
     WriteLine("Products Ordered by Count:");
     var productCounts = productRepository.GetProductByCountShop();
     foreach (var productCount in productCounts)
     {
         var product = productRepository.GetProductById(productCount.ProductId);
         
         if (product == null)
         {
             throw new Exception("product is null!!");
         }
         
         WriteLine($"Product: {product.Name} - Count: {productCount.Count}");
     }
 }

 void ShowUsers()
 {
     var users = userRepository.GetUsersDto();
     
     foreach (var user in users)
     {
         WriteLine($"{user.Id}-{user.FirstName} {user.LastName}\tPhone Number:{user.PhoneNumber} " +
                   $"Email:{user.Email}");
     }
 }

 void DeleteStore()
 {
     ShowStores();
     var storeId = GetUserIntNumber("store id");

     var store = storeRepository.GetStoreById(storeId);
     
     if (store ==null)
     {
         throw new Exception("store is not found!!");
     }
     storeRepository.DeleteStore(store);

 }

 void DeleteProduct()
 {
     ShowProducts();
     var productId = GetUserIntNumber("product id");
     var product = productRepository.GetProductById(productId);
     
     if (product == null)
     {
         throw new Exception("product is null!!");
     }
     productRepository.DeleteProduct(product);
 }

 Customer DeleteCustomer()
 {
     ShowCustomers();
     var customerId = GetUserIntNumber("customer id");
     var customer = customerRepository.GetCustomerById(customerId);
     
     if (customer ==null)
     {
         throw new Exception("Customer was not found!!");
     }
     customerRepository.DeleteCustomer(customer);

     return customer;
 }

 void DeleteUser(int userId)
 {
     var user = userRepository.GetByUserId(userId);
     
     if (user==null)
     {
         throw new Exception("user was not found!!");
     }
     userRepository.DeleteUser(user);
 }

 Employee DeleteEmployee()
 {
     ShowEmployees();
     var employeeId = GetUserIntNumber("Employee id");
     var employee = employeeRepository.GetEmployeeById(employeeId);
     
     if (employee ==null)
     {
         throw new Exception("employee was not found!!");
     }
     employeeRepository.DeleteEmployee(employee);

     return employee;
 }
 