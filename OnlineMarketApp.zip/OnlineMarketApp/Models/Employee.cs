namespace OnlineMarketApp.Models;

public class Employee
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public string PersonalId { get; set; }
    public int? StoreId { get; set; }
    public Store? Store { get; set; }
}