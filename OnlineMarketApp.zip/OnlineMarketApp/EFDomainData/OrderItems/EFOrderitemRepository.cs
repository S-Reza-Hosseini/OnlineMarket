using OnlineMarketApp.Models;

namespace OnlineMarketApp.OrderItems;

public class EFOrderitemRepository(EFDataContext context)
{
    public void AddOrderItem(Order order)
    {
        context.Set<OrderItem>().AddRange(order.OrderItems);
    }
}