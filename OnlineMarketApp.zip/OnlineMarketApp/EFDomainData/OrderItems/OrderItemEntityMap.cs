using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OnlineMarketApp.Models;

namespace OnlineMarketApp.OrderItems;

public class OrderItemEntityMap:IEntityTypeConfiguration<OrderItem>
{
    public void Configure(EntityTypeBuilder<OrderItem> builder)
    {
        builder.HasKey(_ => _.Id);
        builder.Property(_ => _.Id).UseIdentityColumn();
        builder.Property(_ => _.Quantity).IsRequired();
        builder.Property(_ => _.Price).IsRequired().HasColumnType("decimal(8,2)");
        builder.HasOne(_ => _.order)
            .WithMany(_ => _.OrderItems).HasForeignKey(_ => _.OrderId);

    }
}