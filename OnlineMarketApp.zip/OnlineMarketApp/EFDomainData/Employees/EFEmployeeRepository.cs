using OnlineMarketApp.Dtos.Customers;
using OnlineMarketApp.Dtos.Employees;
using OnlineMarketApp.Models;
using static System.Console;

namespace OnlineMarketApp.Employees;

public class EFEmployeeRepository(EFDataContext context)
{
    public void AddEmployee(Employee employee)
    {
        context.Set<Employee>().Add(employee);
        
    }

    public List<ShowEmployeeDto> GetEmployeeDto()
    {
        return (
            from employee in context.Set<Employee>()
            join user in context.Set<User>()
                on employee.UserId equals user.Id
                into personnelUsers
            from personnelUser in personnelUsers.DefaultIfEmpty()
            select new ShowEmployeeDto()
            {
                Id = employee.Id,
                FirstName = personnelUser.FirstName,
                LastName = personnelUser.LastName,
                PhoneNumber = personnelUser.PhoneNumber,
                Email = personnelUser.Email,
                PersonnelId = employee.PersonalId,
                StoreName =  employee.Store.Name != null? employee.Store.Name : "unemployed"
                
            }).ToList();
    }
    
    public void DeleteEmployee(Employee employee)
    {
        context.Set<Employee>().Remove(employee);
        
    }

    public Employee? GetEmployeeById(int employeeId)
    {
        return context.Set<Employee>().FirstOrDefault(_ => _.Id == employeeId);
    }
}