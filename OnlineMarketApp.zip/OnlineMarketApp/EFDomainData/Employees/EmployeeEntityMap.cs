using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OnlineMarketApp.Models;

namespace OnlineMarketApp.Employees;

public class EmployeeEntityMap:IEntityTypeConfiguration<Employee>
{
    public void Configure(EntityTypeBuilder<Employee> builder)
    {
        builder.HasKey(_ => _.Id);
        builder.Property(_ => _.Id).UseIdentityColumn();
        builder.Property(_ => _.PersonalId).IsRequired().HasMaxLength(9);
        builder.Property(_ => _.StoreId).IsRequired(false);
        builder
            .HasOne(_ => _.Store)
            .WithMany(_ => _.Employees)
            .HasForeignKey(_ => _.StoreId);
    }
}