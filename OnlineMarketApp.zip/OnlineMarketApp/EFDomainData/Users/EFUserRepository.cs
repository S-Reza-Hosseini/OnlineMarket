using OnlineMarketApp.Dtos.Users;
using OnlineMarketApp.Models;
using static System.Console;

namespace OnlineMarketApp.Users;

public class EFUserRepository(EFDataContext context)
{
    public int AddUser(User user)
    {
        context.Set<User>().Add(user);
        
        return user.Id;
    }
    
    public List<ShowUserDto> GetUsersDto()
    {
        return (
            from user in context.Set<User>()
            select new ShowUserDto()
            {
                Id = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName,
                PhoneNumber = user.PhoneNumber,
                Email = user.Email == null?"null" :user.Email
            }).ToList();
    }
    
    public void DeleteUser(User user)
    {
        context.Set<User>().Remove(user);
        
    }

    public User? GetByUserId(int userId)
    {
        return context.Set<User>().FirstOrDefault(_ => _.Id == userId);
    }
}