using OnlineMarketApp.Dtos.Customers;
using OnlineMarketApp.Models;
using static System.Console;

namespace OnlineMarketApp.Customers;

public class EFCustomerRepository(EFDataContext context)
{
    public void  AddCustomer(Customer customer)
    {
        context.Set<Customer>().Add(customer);
        
    }
    
    public List<ShowCustomerDto> GetCustomersDto()
    {
        return  (from customer in context.Set<Customer>()
            join user in context.Set<User>()
                on customer.UserId equals user.Id
                into customerUsers
            from customerUser in customerUsers.DefaultIfEmpty()
            select new ShowCustomerDto()
            {
                Id = customer.Id,
                FirstName = customerUser.FirstName,
                LastName = customerUser.LastName,
                PhoneNumber = customerUser.PhoneNumber,
                Email = customerUser.Email,
                Address = customer.Address,
                PostalCode = customer.PostalCode
                
            }).ToList();
    }
    public void DeleteCustomer(Customer customer)
    {
        context.Set<Customer>().Remove(customer);
    }

    public Customer? GetCustomerById(int customerId)
    {
        return context.Set<Customer>().FirstOrDefault(_ => _.Id == customerId);
    }
}