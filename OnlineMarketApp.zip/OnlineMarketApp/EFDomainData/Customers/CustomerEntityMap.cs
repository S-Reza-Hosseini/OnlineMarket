using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OnlineMarketApp.Models;

namespace OnlineMarketApp.Customers;

public class CustomerEntityMap:IEntityTypeConfiguration<Customer>
{
    public void Configure(EntityTypeBuilder<Customer> builder)
    {
        builder.HasKey(_ => _.Id);
        builder.Property(_ => _.Id).UseIdentityColumn();
        builder.Property(_ => _.Address).IsRequired().HasMaxLength(500);
        builder.Property(_ => _.PostalCode).IsRequired().HasMaxLength(16);

    }
}