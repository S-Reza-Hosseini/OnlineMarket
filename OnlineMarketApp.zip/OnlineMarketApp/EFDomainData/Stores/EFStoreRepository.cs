using System.Xml;
using OnlineMarketApp.Dtos.Stores;
using OnlineMarketApp.Models;

namespace OnlineMarketApp.Stores;

public class EFStoreRepository(EFDataContext context)
{
    public void AddStore(Store store)
    {
        context.Set<Store>().Add(store);
    }
    
    public void DeleteStore(Store store)
    {
        context.Set<Store>().Remove(store);
        
    }
    public Store? GetStoreById(int storeId)
    {
        return context.Set<Store>()
            .FirstOrDefault(_=>_.Id == storeId);
    }

    public List<ShowStoreDto> GetStoresDto()
    {
        return (
            from store in context.Set<Store>()
            select new ShowStoreDto()
            {
                Id = store.Id,
                Name = store.Name
            }
        ).ToList();
        
    }
    
}