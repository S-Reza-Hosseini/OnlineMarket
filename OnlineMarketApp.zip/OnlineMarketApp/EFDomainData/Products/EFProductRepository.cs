using Microsoft.EntityFrameworkCore.Metadata.Internal;
using OnlineMarketApp.Dtos.Products;
using OnlineMarketApp.Models;
using static System.Console;

namespace OnlineMarketApp.Products;

public class EFProductRepository(EFDataContext context)
{
    public void AddProduct(Product product)
    {
       context.Set<Product>().Add(product);
    }
    
    public List<ShowProductDto> GetProductsDto()
    {
        return  (
            from product in context.Set<Product>()
            select new ShowProductDto()
            {
                Name = product.Name,
                Id = product.Id,
                Price = product.Price,
                Description = product.Description
                
            }).ToList();
    }
    public List<ShowProductByCountShopDto> GetProductByCountShop()
    {
        return context.Set<OrderItem>()
            .GroupBy(oi => oi.ProductId)
            .Select(g => new
            {
                ProductId = g.Key,
                Count = g.Count()
            })
            .OrderByDescending(x => x.Count)
            .Select(_=> new ShowProductByCountShopDto()
            {
                ProductId = _.ProductId,
                Count = _.Count,
            })
            .ToList();
        
    }
    public void DeleteProduct(Product product)
    {
        context.Set<Product>().Remove(product);
    }

    public decimal GetPriceWithProductId(int productId)
    {
        var price = context.Set<Product>()
            .Where(_ => _.Id == productId)
            .Select(_ => _.Price).FirstOrDefault();

        return price;
    }

    public Product? GetProductById(int productId)
    {
        return context.Set<Product>().FirstOrDefault(p => p.Id == productId);
    }
}