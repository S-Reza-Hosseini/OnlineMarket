using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OnlineMarketApp.Models;

namespace OnlineMarketApp.Products;

public class ProductEntityMap:IEntityTypeConfiguration<Product>
{
    public void Configure(EntityTypeBuilder<Product> builder)
    {
        builder.HasKey(_ => _.Id);
        builder.Property(_ => _.Id).UseIdentityColumn();
        builder.Property(_ => _.Name).IsRequired().HasMaxLength(256);
        builder.Property(_ => _.Price).IsRequired().HasColumnType("decimal(8,2)");
        builder.Property(_ => _.Description).IsRequired(false).HasMaxLength(500);
        builder
            .HasOne(_ => _.Store)
            .WithMany(_ => _.Products)
            .HasForeignKey(_ => _.StoreId);

    }
}