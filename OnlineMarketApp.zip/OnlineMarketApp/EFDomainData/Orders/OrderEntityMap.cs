using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OnlineMarketApp.Models;

namespace OnlineMarketApp.Orders;

public class OrderEntityMap:IEntityTypeConfiguration<Order>
{
    public void Configure(EntityTypeBuilder<Order> builder)
    {
        builder.HasKey(_ => _.Id);
        builder.Property(_ => _.Id).UseIdentityColumn();
        builder.Property(_ => _.TotalPrice).HasColumnType("decimal(8,2)");
        builder.Property(_ => _.OrderDate).IsRequired();
        builder
            .HasOne(_ => _.Customer)
            .WithMany(_ => _.Orders)
            .HasForeignKey(_ => _.CustomerId);
    }
}