using OnlineMarketApp.Dtos.Orders;
using OnlineMarketApp.Models;
using static System.Console;

namespace OnlineMarketApp.Orders;

public class EFOrderRepository(EFDataContext context)
{
    public void AddShopping(Order order)
    {

        context.Set<Order>().Add(order);
    }
    
    public void UpdateOrder(Order order)
    {
        context.Set<Order>().Update(order);
    }
    
    public List<ShowOrderDto> GetOrders()
    {
        return  (
            from order in context.Set<Order>()
            join orderItem in context.Set<OrderItem>()
                on order.Id equals orderItem.OrderId
            join product in context.Set<Product>()
                on orderItem.ProductId equals product.Id
                join user in context.Set<User>()
                on order.Customer.UserId equals user.Id
            select new ShowOrderDto()
            {
                Id = order.Id,
                Date = order.OrderDate,
                CustomerName = user.FirstName,
                ProductName = product.Name,
                Quantity = orderItem.Quantity,
                Price = order.TotalPrice
            }).ToList();
    }

}